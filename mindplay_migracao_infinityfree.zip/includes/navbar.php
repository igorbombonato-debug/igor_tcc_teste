<?php
// Monta a navegação compartilhada e exibe links conforme o perfil autenticado.
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$user = get_logged_user();
// Marca como ativa a página cujo nome corresponde ao arquivo aberto.
$activePage = basename($_SERVER['PHP_SELF']);
?>
<nav class="navbar navbar-expand-lg navbar-dark fixed-top shadow-sm">
    <div class="container">
        <a class="navbar-brand" href="<?php echo is_logged_in() ? '/public/dashboard.php' : '/public/login.php'; ?>">
            <img class="navbar-brand-icon" src="/assets/img/mindplay-icon.png" alt="">
            <span>MindPlay</span>
        </a>

        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNavbar" aria-controls="mainNavbar" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="mainNavbar">
            <?php if (is_logged_in()): ?>
                <ul class="navbar-nav mx-auto mb-2 mb-lg-0">
                    <?php if (($user['tipo'] ?? '') === 'professor'): ?>
                        <li class="nav-item"><a class="nav-link <?php echo $activePage === 'index.php' ? 'active' : ''; ?>" href="/professor/index.php">Acompanhamento</a></li>
                    <?php else: ?>
                        <li class="nav-item"><a class="nav-link <?php echo $activePage === 'dashboard.php' ? 'active' : ''; ?>" href="/public/dashboard.php">Início</a></li>
                        <li class="nav-item"><a class="nav-link <?php echo $activePage === 'materias.php' ? 'active' : ''; ?>" href="/public/materias.php">Matérias</a></li>
                        <li class="nav-item"><a class="nav-link <?php echo $activePage === 'ranking.php' ? 'active' : ''; ?>" href="/public/ranking.php">Ranking</a></li>
                        <li class="nav-item"><a class="nav-link <?php echo $activePage === 'desempenho.php' ? 'active' : ''; ?>" href="/public/desempenho.php">Desempenho</a></li>
                        <li class="nav-item"><a class="nav-link <?php echo $activePage === 'historico.php' ? 'active' : ''; ?>" href="/public/historico.php">Histórico</a></li>
                        <li class="nav-item"><a class="nav-link <?php echo $activePage === 'perfil.php' ? 'active' : ''; ?>" href="/public/perfil.php">Perfil</a></li>
                    <?php endif; ?>
                    <?php if (!empty($user) && $user['tipo'] === 'admin'): ?>
                        <li class="nav-item"><a class="nav-link <?php echo in_array($activePage, ['index.php','usuarios.php','questoes.php','materias.php','desempenho.php','partidas.php']) ? 'active' : ''; ?>" href="/admin/index.php">Admin</a></li>
                    <?php endif; ?>
                </ul>
                <div class="d-flex align-items-center gap-3">
                    <div class="user-pill">
                        <span class="avatar-mini">
                            <?php if ($avatarUrl = avatar_url($user['avatar'] ?? '')): ?>
                                <img src="<?php echo e($avatarUrl); ?>" alt="Foto de perfil de <?php echo e($user['nome'] ?? 'Usuário'); ?>">
                            <?php else: ?>
                                <?php echo strtoupper(substr($user['nome'] ?? 'U', 0, 1)); ?>
                            <?php endif; ?>
                        </span>
                        <span><?php echo e($user['nome'] ?? 'Usuário'); ?></span>
                    </div>
                    <a href="/public/logout.php" class="btn btn-outline-light btn-sm">Sair</a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</nav>
