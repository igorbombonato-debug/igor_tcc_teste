<?php
// Registra respostas durante a partida ou grava seu resultado final.
// Associa os dados ao usuário autenticado na sessão e responde em JSON.
// Informa ao navegador que esta API sempre responde em JSON UTF-8.
header('Content-Type: application/json; charset=utf-8');

// Garante que o ID da partida possa ser mantido entre requisições.
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Carrega a conexão e as funções usadas para registrar resultados.
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

// Converte o corpo JSON enviado pelo jogo em um array PHP.
$input = file_get_contents('php://input');
$data = $input !== '' ? json_decode($input, true) : [];
if (!is_array($data)) {
    $data = [];
}

// Dados de partida podem vir agrupados no campo partida.
$partida = isset($data['partida']) && is_array($data['partida']) ? $data['partida'] : [];

// Usa exclusivamente o usuário autenticado na sessão para associar resultados.
$usuarioId = (int) ($_SESSION['user_id'] ?? 0);
if ($usuarioId <= 0) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Usuário não autenticado.']);
    exit;
}

$stmt = $pdo->prepare('SELECT id, tipo, ano_escolar FROM usuarios WHERE id = :id AND tipo IN (\'aluno\', \'admin\') AND ativo = 1 LIMIT 1');
$stmt->execute(['id' => $usuarioId]);
$usuario = $stmt->fetch();
if (!$usuario) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Este perfil não pode registrar resultados de jogos.']);
    exit;
}

// Alunos usam a série gravada na conta; admins precisam informar uma série válida.
$anoEscolarPermitido = $usuario['tipo'] === 'aluno'
    ? (int) $usuario['ano_escolar']
    : (int) ($data['ano_escolar'] ?? $partida['ano_escolar'] ?? 0);
if ($anoEscolarPermitido <= 0) {
    http_response_code(422);
    echo json_encode(['success' => false, 'message' => 'Série escolar inválida.']);
    exit;
}

// Normaliza os dados e confirma que a matéria pertence à série autorizada.
$materiaId = (int) ($data['materia_id'] ?? $partida['materia_id'] ?? 0);
if ($materiaId <= 0) {
    $materiaPadrao = $pdo->prepare('SELECT id FROM materias WHERE ano_escolar = :ano AND ativo = 1 ORDER BY id LIMIT 1');
    $materiaPadrao->execute(['ano' => $anoEscolarPermitido]);
    $materiaId = (int) $materiaPadrao->fetchColumn();
}
$materiaValida = $pdo->prepare('SELECT id FROM materias WHERE id = :id AND ano_escolar = :ano AND ativo = 1 LIMIT 1');
$materiaValida->execute(['id' => $materiaId, 'ano' => $anoEscolarPermitido]);
if (!$materiaValida->fetch()) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Esta matéria não pertence à sua série.'], JSON_UNESCAPED_UNICODE);
    exit;
}

$questaoId = isset($data['questao_id']) ? (int) $data['questao_id'] : 0;
if ($questaoId > 0) {
    $questaoValida = $pdo->prepare('SELECT q.id FROM questoes q
        INNER JOIN materias m ON m.id = q.materia_id AND m.ano_escolar = q.ano_escolar
        WHERE q.id = :questao_id AND q.materia_id = :materia_id AND q.ano_escolar = :ano
          AND q.ativo = 1 AND m.ativo = 1 LIMIT 1');
    $questaoValida->execute(['questao_id' => $questaoId, 'materia_id' => $materiaId, 'ano' => $anoEscolarPermitido]);
    if (!$questaoValida->fetch()) {
        http_response_code(403);
        echo json_encode(['success' => false, 'message' => 'A questão não pertence à matéria e série selecionadas.'], JSON_UNESCAPED_UNICODE);
        exit;
    }
}
$respostaUsuario = isset($data['resposta_usuario']) ? strtoupper((string) $data['resposta_usuario']) : null;
$respostaCorreta = isset($data['resposta_correta']) ? trim((string) $data['resposta_correta']) : null;
$enunciadoSnapshot = isset($data['questao_enunciado']) ? trim((string) $data['questao_enunciado']) : null;
$jogadorNome = isset($data['jogador_nome']) ? trim((string) $data['jogador_nome']) : null;
$timeJogador = isset($data['time_jogador']) && in_array($data['time_jogador'], ['azul', 'vermelho'], true) ? $data['time_jogador'] : null;
$correta = isset($data['correta']) ? (int) $data['correta'] : 0;
$tempoResposta = isset($data['tempo_resposta']) ? (int) $data['tempo_resposta'] : 0;
$finalizar = !empty($data['finalizar']);

// Limpa a partida anterior quando o jogador inicia uma nova partida.
if (!empty($data['nova_partida'])) {
    unset($_SESSION['partida_atual']);
}

if ($finalizar) {
    // Reúne os totais finais enviados pelo jogo.
    $jogo = $data['jogo'] ?? $partida['jogo'] ?? 'queimada';
    $pontuacao = (int) ($data['pontuacao'] ?? $partida['pontuacao'] ?? 0);
    $xpGanho = (int) ($data['xp_ganho'] ?? $partida['xp_ganho'] ?? 0);
    $acertos = (int) ($data['acertos'] ?? $partida['acertos'] ?? 0);
    $erros = (int) ($data['erros'] ?? $partida['erros'] ?? 0);
    $totalQuestoes = (int) ($data['total_questoes'] ?? $partida['total_questoes'] ?? 0);
    $tempo = (int) ($data['tempo'] ?? $partida['tempo'] ?? 0);
    $anoEscolar = $anoEscolarPermitido;
    $equipeNomes = isset($data['equipe_nomes']) ? json_encode($data['equipe_nomes'], JSON_UNESCAPED_UNICODE) : null;

    // Atualiza a partida já criada durante as respostas ou cria uma nova.
    $partidaId = $_SESSION['partida_atual'] ?? 0;
    if ($partidaId > 0) {
        // Salva o resultado final na partida existente.
        $stmt = $pdo->prepare('UPDATE partidas SET jogo = :jogo, materia_id = :materia_id, ano_escolar = :ano_escolar, dificuldade = :dificuldade, pontuacao = :pontuacao, xp_ganho = :xp_ganho, acertos = :acertos, erros = :erros, total_questoes = :total_questoes, tempo = :tempo, equipe_nomes = :equipe_nomes, created_at = created_at WHERE id = :id');
        $stmt->execute([
            'jogo' => $jogo,
            'materia_id' => $materiaId,
            'ano_escolar' => $anoEscolar,
            'dificuldade' => $data['dificuldade'] ?? $partida['dificuldade'] ?? 'Médio',
            'pontuacao' => $pontuacao,
            'xp_ganho' => $xpGanho,
            'acertos' => $acertos,
            'erros' => $erros,
            'total_questoes' => $totalQuestoes,
            'tempo' => $tempo,
            'equipe_nomes' => $equipeNomes,
            'id' => $partidaId,
        ]);
    } else {
        // Cria uma partida para jogos individuais que só enviam o resultado final.
        $partidaId = registrar_partida([
            'usuario_id' => $usuarioId,
            'jogo' => $jogo,
            'materia_id' => $materiaId,
            'ano_escolar' => $anoEscolar,
            'dificuldade' => $data['dificuldade'] ?? 'Médio',
            'pontuacao' => $pontuacao,
            'xp_ganho' => $xpGanho,
            'acertos' => $acertos,
            'erros' => $erros,
            'total_questoes' => $totalQuestoes,
            'tempo' => $tempo,
            'equipe_nomes' => $equipeNomes,
        ]);
    }

    // A Memória envia tentativas sem questão vinculada; preserva os detalhes no histórico.
    $respostasDetalhadas = $data['respostas'] ?? [];
    if (is_array($respostasDetalhadas)) {
        $stmtResposta = $pdo->prepare('INSERT INTO respostas (partida_id, questao_id, resposta_usuario, enunciado_snapshot, resposta_correta, correta, tempo_resposta, created_at)
            VALUES (:partida_id, NULL, :resposta_usuario, :enunciado, :resposta_correta, :correta, 0, NOW())');
        foreach ($respostasDetalhadas as $resposta) {
            if (!is_array($resposta)) {
                continue;
            }
            $stmtResposta->execute([
                'partida_id' => $partidaId,
                'resposta_usuario' => mb_substr(trim((string) ($resposta['resposta_usuario'] ?? '')), 0, 255),
                'enunciado' => trim((string) ($resposta['enunciado'] ?? '')),
                'resposta_correta' => mb_substr(trim((string) ($resposta['resposta_correta'] ?? '')), 0, 255),
                'correta' => !empty($resposta['correta']) ? 1 : 0,
            ]);
        }
    }

    // Atualiza XP, nível, fase, pontos e desempenho do aluno no fechamento.
    $progresso = atualizar_xp_e_nivel($usuarioId, $xpGanho);
    atualizar_pontos($usuarioId, $pontuacao);
    atualizar_desempenho_usuario($usuarioId, $materiaId, $acertos, $erros);
    // Libera a sessão para que a próxima partida seja independente.
    unset($_SESSION['partida_atual']);

    $faseAlcancada = $progresso['mudou_fase']
        ? ['numero' => $progresso['fase_nova'], 'nome' => $progresso['nome_fase']]
        : null;
    echo json_encode([
        'success' => true,
        'partida_id' => $partidaId,
        'finalizado' => true,
        'fase_alcancada' => $faseAlcancada,
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

// Recupera ou cria a partida que receberá esta resposta.
$partidaId = $_SESSION['partida_atual'] ?? 0;
if ($partidaId <= 0) {
    // A primeira resposta cria o registro base da nova partida.
    $partidaId = registrar_partida([
        'usuario_id' => $usuarioId,
        'jogo' => $data['jogo'] ?? $partida['jogo'] ?? 'queimada',
        'materia_id' => $materiaId,
        'ano_escolar' => $anoEscolarPermitido,
        'dificuldade' => $data['dificuldade'] ?? $partida['dificuldade'] ?? 'Médio',
        'pontuacao' => 0,
        'xp_ganho' => 0,
        'acertos' => 0,
        'erros' => 0,
        'total_questoes' => 0,
        'tempo' => 0,
    ]);
    $_SESSION['partida_atual'] = $partidaId;
}

if ($questaoId > 0) {
    // Guarda a questão, resposta, jogador e time que participaram da rodada.
    $stmt = $pdo->prepare('INSERT INTO respostas (partida_id, questao_id, resposta_usuario, jogador_nome, time_jogador, enunciado_snapshot, resposta_correta, correta, tempo_resposta, created_at) VALUES (:partida_id, :questao_id, :resposta_usuario, :jogador_nome, :time_jogador, :enunciado, :resposta_correta, :correta, :tempo_resposta, NOW())');
    $stmt->execute([
        'partida_id' => $partidaId,
        'questao_id' => $questaoId,
        'resposta_usuario' => $respostaUsuario,
        'jogador_nome' => $jogadorNome,
        'time_jogador' => $timeJogador,
        'enunciado' => $enunciadoSnapshot,
        'resposta_correta' => $respostaCorreta,
        'correta' => $correta,
        'tempo_resposta' => $tempoResposta,
    ]);

}

// Acumula pontuação e quantidade de acertos/erros na partida.
$stmt = $pdo->prepare('UPDATE partidas SET pontuacao = pontuacao + :pontuacao, xp_ganho = xp_ganho + :xp_ganho, acertos = acertos + :acertos, erros = erros + :erros, total_questoes = total_questoes + 1 WHERE id = :id');
$stmt->execute([
    'pontuacao' => (int) ($data['pontuacao'] ?? $partida['pontuacao'] ?? 0),
    'xp_ganho' => (int) ($data['xp_ganho'] ?? $partida['xp_ganho'] ?? 0),
    'acertos' => $correta ? 1 : 0,
    'erros' => $correta ? 0 : 1,
    'id' => $partidaId,
]);

echo json_encode(['success' => true, 'partida_id' => $partidaId, 'finalizado' => false]);
