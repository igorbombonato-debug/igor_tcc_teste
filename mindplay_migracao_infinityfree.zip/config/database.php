<?php

// Configura e abre a conexão compartilhada com o banco de dados MySQL da aplicação.
// Endereço local usado pelo MySQL.
$host = 'PREENCHA_COM_O_HOST_MYSQL_DO_INFINITYFREE';
// Porta MySQL informada pela hospedagem (normalmente 3306).
$port = 3306;
// Nome do banco de dados da aplicação.
$dbname = 'PREENCHA_COM_O_NOME_DO_BANCO';
// Usuário local do MySQL.
$dbUser = 'PREENCHA_COM_O_USUARIO_DO_BANCO';
// Informe aqui a senha configurada para o usuário local do MySQL.
$dbPass = 'PREENCHA_COM_A_SENHA_DO_BANCO';

// PDO lança exceções em falhas, retorna colunas por nome e usa prepared statements nativos.
// Opções que deixam o PDO seguro e retornam resultados como arrays associativos.
$options = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES => false,
];

try {
    $pdo = new PDO(
        'mysql:host=' . $host . ';port=' . $port . ';dbname=' . $dbname . ';charset=utf8mb4',
        $dbUser,
        $dbPass,
        $options
    );
} catch (PDOException $e) {
    // Interrompe a página com status HTTP 500 e uma orientação para corrigir a conexão.
    http_response_code(500);
    die(
        'Falha na conexao com o banco MindPlay. Confira config/database.php.'
    );
}
