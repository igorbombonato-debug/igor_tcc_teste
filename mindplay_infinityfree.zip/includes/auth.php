<?php

// Centraliza a inicialização da sessão e as verificações de acesso por perfil.
// Inicia uma sessão somente quando ainda não existe uma ativa.
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/functions.php';

function is_logged_in(): bool
{
    // A presença do ID na sessão indica que o usuário passou pelo login.
    return !empty($_SESSION['user_id']);
}

function require_login(): void
{
    // Evita que o navegador reapresente conteúdo protegido após uma falha ou logout.
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    header('Pragma: no-cache');
    header('Expires: 0');

    // Bloqueia sessões inválidas, contas removidas ou contas desativadas.
    $user = get_logged_user();
    if (!$user || (int) $user['ativo'] !== 1) {
        // Limpa os dados inválidos antes de redirecionar.
        $_SESSION = [];
        session_destroy();
        header('Location: /public/login.php');
        exit;
    }
}

function require_admin(): void
{
    // Primeiro exige uma sessão válida.
    require_login();

    // Depois verifica se o usuário tem permissão administrativa.
    if (empty($_SESSION['user_tipo']) || $_SESSION['user_tipo'] !== 'admin') {
        header('Location: /public/dashboard.php');
        exit;
    }
}

function require_professor(): void
{
    // Confere o perfil usando os dados atuais da conta, não apenas um link acessado.
    require_login();

    $user = get_logged_user();
    if (!$user || $user['tipo'] !== 'professor') {
        header('Location: /public/dashboard.php');
        exit;
    }
}

function require_student(): void
{
    // Restringe a área de aluno exclusivamente a contas de aluno.
    require_login();

    $user = get_logged_user();
    if (!$user || $user['tipo'] !== 'aluno') {
        $destino = $user && $user['tipo'] === 'professor'
            ? '/professor/index.php'
            : '/admin/index.php';
        header('Location: ' . $destino);
        exit;
    }
}

function redirect_if_logged_in(): void
{
    // Impede que um usuário autenticado volte para login ou cadastro.
    $user = is_logged_in() ? get_logged_user() : null;
    if ($user !== null) {
        $destino = $user['tipo'] === 'professor'
            ? '/professor/index.php'
            : '/public/dashboard.php';
        header('Location: ' . $destino);
        exit;
    }

    // Remove uma sessão cujo usuário não existe mais no banco.
    if (is_logged_in()) {
        $_SESSION = [];
        session_destroy();
    }
}

function get_logged_user(): ?array
{
    // Sem ID de sessão, não há usuário para consultar.
    if (!is_logged_in()) {
        return null;
    }

    // Usa a conexão compartilhada criada em config/database.php.
    global $pdo;

    // Busca os dados atuais do usuário pelo ID salvo na sessão.
    $stmt = $pdo->prepare('SELECT * FROM usuarios WHERE id = :id LIMIT 1');
    $stmt->execute(['id' => $_SESSION['user_id']]);
    $user = $stmt->fetch();

    return $user ?: null;
}
